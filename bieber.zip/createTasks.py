import azure.storage.blob as azureblob

container_name = "people"
block_blob_service = BlockBlobService(account_name='demobatch', account_key='nZlBu640ZZjQQvDOmgoTGsacePh4gm+M5cjmtofGX9X+Twx1Fh/BaCcLM7TMwcmhJEnMH8ZzakGAeRIURzTGdw==')

def createSASforAllFilesInContainer(block_blob_service, container_name):
    block_blob_service.list_blobs(container_name)
    return map((lambda blob: block_blob_service.generate_blob_shared_access_signature(container_name, blob.name, azureblob.BlobPermissions.READ, datetime.utcnow() + timedelta(hours=4))))

urls = createSASforAllFilesInContainer(block_blob_service, container_name)

for url in urls:
    print(url)